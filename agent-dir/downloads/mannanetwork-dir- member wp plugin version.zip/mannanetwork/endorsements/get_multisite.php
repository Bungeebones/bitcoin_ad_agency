<? $referer_blog_id = $_GET['referer_blog_id'];
?>

<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h1 align="center">Start Blogging For Free On Your Own Website!</h1></div>
	<div class="modalHeader"><h1 align="center">No Domain Name Needed!</h1></div>
       
            <h2>Get a hosted Wordpress blog site (using a subdomain of any of your preference of the topics below) AND the income earning Web Directory comes installed absolutely free!</h2>
  

		<div style ="width: 75% ;
		  margin-left: auto ;
		  margin-right: auto ;"><table>
		<tr><td>
		AdCoin</td><td width="10px">&nbsp;</td><td>Art</td></tr>
<tr><td>
		Bitcoin</td><td width="10px">&nbsp;</td><td>Finances</td></tr>
		<tr><td>HealthyLiving</td><td width="10px">&nbsp;</td><td>Jesus</td></tr>
		<tr><td>Rand Paul</td><td width="10px">&nbsp;</td><td>Music</td></tr>
		<tr><td>Business</a></td><td width="10px">&nbsp;</td><td>Students</td></tr>
		<tr><td>Co-Operative Fundraising</td><td width="10px">&nbsp;</td><td>Investing Web Traffic</td></tr>
		<tr><td>Web Traffic MLS</td><td width="10px">&nbsp;</td><td>Word Press Monetization Systems</td></tr>
		</table>
		</div><!-- close table div -->

	<iframe src="https://Bungeebones.com/members/pmu_get_wpmu_reg_by_referer_or_affil.php?referer_affiliate_num=
	<?echo $_GET['affiliate_num'];?>" width="100%" height="550"]
	</iframe>
   
    </div>  <!-- close line 6 div -->   
    	<div class="modalFooter">
                 <div class="acc-section">
				<div style="text-align: center;">
				<p>Get your own free blog and earn Bitcoin too!</p>
				</div> 
 			<a href="<?php echo get_permalink(); ?>" title="Cancel" class="cancel">Cancel</a>
           		 	<div class="clear"></div>
       		 </div>
  	</div>
</div> <!-- close line 5 div -->
</div> <!-- close line 4 div -->
