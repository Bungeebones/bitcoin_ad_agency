<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h1 align="center">The BungeeBones Monetization System Plugin For Wordpress</h1></div>
            <p align="left">This plugin installs the fully populated (with links and categories) Web Directory in your Wordpress blog. It does require registration at BungeeBones.com to enable earning commissions and to download the plugin.</p>
            
</div>     
    <div class="modalFooter">
           
                  <div class="acc-section">
				<div style="text-align: center;">
		

<p>Get your own free blog and earn Bitcoin too!</p>
<div style="text-align: center;">
<iframe src="http://Bungeebones.com/members/omni_register.php?affiliate_num=<?echo $_GET['affiliate_num'];?>&script_type=wp_plugin" width="100%" height="750"]
		</iframe>		
			</div> 
        </div>
  </div>
</div>
</div>
