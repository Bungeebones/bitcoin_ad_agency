<? $referer_blog_id = $_GET['referer_blog_id'];
?>

<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h1 align="center">Start Blogging For Free On Your Own Website!</h1></div>
            <h2>Get a hosted Wordpress blog site AND the Web Directory installed absolutely free!</h2>
           <h3>Here's the deal ... if you don't make enough income from the monetization program (i.e. the web directory) then the hosting is on us*!</h3>
<p align="left">Use the contact form and and tell us about yourself, your blog and/or your idea!.

<p>* This offer is limited to those with demonstrated blogging ability (either already operate a blog or other related experience). For approved applicants, for up to one year, if your site doesn't earn enough to pay the monthly hosting fee then whatever amount is outstanding is forgiven. If your site had some earnings then whatever it did earn will be applied to the hosting fee.
</div>     
    <div class="modalFooter">
           
                  <div class="acc-section">
				<div style="text-align: center;">
		

<p>Get your own free blog and earn Bitcoin too!</p>
</div> 
 <a href="<?php echo get_permalink(); ?>" title="Cancel" class="cancel">Cancel</a>
            <div class="clear"></div>
        </div>
  </div>
</div>
</div>
