<? $affiliate_num = $_GET['affiliate_num'];
?>

<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h2 align="center">Earn Income With A Web Directory!</h2></div> 
            <p align="left">Use our web directory system and co-operate with other sites to advertise each other's websites and earn income (either in the form of Bitcoin or advertising credits) too, with your own web directory. Even if you don't currently have a website ... </p>
       <p  align="left">Your web directory is totally and completely managed for you, too, so it is absolutely maintenance free. 
<p  align="left">And it is available for free!
<h1 style="text-align: center;">Website Options</h1>

<p class="smallerFont" >We have four different programs to fit your needs.
</td></tr>
<tr><td colspan="2" width="100%"><h3>If You Need A Website ...</h3>
<div  class="grid_12"  style="background-color:lightgrey; height:880px; border: 2px solid; border-radius: 25px; padding:10px 10px 10px;  margin-left: auto ;
  margin-right: auto ;">
<h4>1) Get A Free Personal MultiSite Blog </h4>
<p class="smallerFont" ><ul style="padding:10px 10px 10px;"><li>No domain name needed</li><li>No hosting fee</li><li>Easy to operate</li><li>Same full income earning opportunities as other programs</li><li>No CPanel</li><li>Can't add plugins (can request them)</li><li>Can't add themes/templates (can request them)</li></ul>
</p><p>
<a href="?get_multisite=true&affiliate_num=<?echo $affiliate_num;?>"><h4>Get A Multi-Site Blog<br> (i.e. your own personal blog as a subdomain )</h4></a>
<h4>2) Get A "Free*" Hosted Blog</h4>
<p class="smallerFont" ><ul style="padding:10px 10px 10px;"><li>You can use your own domain name</li><li>Comes with our Hosting Fee Partnership Program *</li><li>Easy to operate</li><li>Same full income earning opportunities as other programs</li><li>Comes with its own CPanel</li><li>Can add plugins</li><li>Can add themes/templates</li></ul>
</p>
<p class="smallerFont" >* The Hosting fee partnership programs says that if you don't earn enough income from your blog to pay the modest hosting fee then the hosting is on us!
<p>
<a href="?get_hosting=true&affiliate_num=<?echo $affiliate_num;?>"><h4>Get A Hosted Blog</h4></a>
</div>
</td></tr>
<tr><td colspan="2" width="100%">&nbsp;</td></tr>
<tr><td colspan="2" width="100%"><h3>But If You Have A Website Already ...</h3>
<div  class="grid_12"  style="background-color:lightgrey;  height:620px; border: 2px solid; border-radius: 25px; padding:10px 10px 10px;  margin-left: auto ;
  margin-right: auto ;">
<h4>1) For Those With A Wordpress Site, Download The Web Directory Plugin</h4>
<p class="smallerFont" >The plugin also comes with free web directory management services from BungeeBones. It also comes complete with categories and links. When your visitors decide to "Add Their Link" to it, the link is also distributed to all other web directories (thus making your advertising offer more valuable).
<a href="?get_plugin=true&affiliate_num=<?echo $affiliate_num;?>"><h4>Download Plugin</h4></a>
</td></tr>

<tr><td colspan="2" width="100%"><h4>Or For Those With A PHP Website</h4>
<h4>2) Download A PHP Web Directory Script</h4>

<p class="smallerFont" >The web directory also comes as a PHP script that you enter into one of your own website pages. It is completely brandable to your own website and like the other versions comes complete with categories, links and management ... all free!
<a href="?get_php_code=true&affiliate_num=<?echo $affiliate_num;?>"><h4>Download PHP Script</h4></a>
</div>
</td></tr>
</div>     

   <div class="modalFooter">
           
                  <div class="acc-section">
			
            <div class="clear"></div>
        </div>
  </div>
</div>
</div>

