<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h1 align="center">The BungeeBones Monetization System Plugin For Wordpress</h1></div>
            <p align="left">This plugin installs the fully populated (with links and categories) Web Directory in your Wordpress blog. It does require registration at BungeeBones.com to enable earning commissions and to download the plugin.</p>
            
</div>     
    <div class="modalFooter">
           
                  <div class="acc-section">
			
		

<p>Get your own free blog and earn Bitcoin too!</p>
<div style="text-align:left;">
<a href="https://Bungeebones.com/members/omni_register.php?affiliate_num=<?echo $_GET['affiliate_num'];?>&script_type=wp_plugin" target="popup" onclick="window.open('https://Bungeebones.com/members/omni_register.php?affiliate_num=<?echo $_GET['affiliate_num'];?>&script_type=wp_plugin','name','width=600,height=400')"><h3 style='color:blue; text-decoration: underline;'>
Step 1 - Register</h3>
<h3>Step 2 - Confirm your email address</h3>
<h3>Step 3 - Login at Bungeebones.com, add your website information, and download your plugin</h3>
<h3>Step 4 - Install and configure your plugin</h3></a>	
			
        </div>
  </div>
</div>
</div>
