

<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h1 align="center">About Bitcoin</h1></div>
            <p align="left">Bitcoin is a new and revolutionary web technology that can be used for many things but in the case of our blogging club we use it as currency. Any advertising fees that a web site chooses to incur to move their site into a more prominent position are paid using Bitcoin (unless the buyer has earned advertising credits and is using those instead). Also, all commissions paid to club members for their advertising sales are paid out in Bitcoin.</p>
            <p  align="left">You can find a lot of information about Bitcoin on the web. It has been out now about 5 years and there are many excellent YouTube videos, many excellent web sites, and many excellent news articles. There are also some pretty porr ones written or produced by ill informed producers. So for that reason we provide this list of links to sources we recommend.   
         
     </div>     

   <div class="modalFooter">
           
                  <div class="acc-section">
			
            <div class="clear"></div>
        </div>
  </div>
</div>
</div>


