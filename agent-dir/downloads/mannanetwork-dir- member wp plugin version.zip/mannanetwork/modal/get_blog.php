

<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h1 align="center">Ready To Start Blogging?</h1></div>
            <p align="left">Join our Blog4Bitcoin Club and get a free Wordpress blog site AND the Web Directory installed absolutely free!</p>
            
</div>   
<? include('footer.php');

?>
            <div class="clear"></div>
        </div>
  </div>
</div>
</div>

