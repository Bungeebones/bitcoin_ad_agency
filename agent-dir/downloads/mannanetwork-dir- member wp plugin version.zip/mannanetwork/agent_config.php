<?php
$agent_url = "agent1.com";
$agent_member_folder = "manna-network";
$agent_link_folder = "mannanetwork-dir";
?>
