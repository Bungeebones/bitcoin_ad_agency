<div id="openModal" class="modalWindow">
       <div class="modalHeader"><h1 align="center">Thank You For Wanting To Add Your Link To Our Web Directory!</h1></div>
            <p align="left">Our's is one of a network of many on individually owned and operated websites that co-operate together to advertise each other's websites and your website will be advertised on the entire network as well as our own site. It's a better way for us to help even more people find your website than what just our own site could provide you by itself.</p>
            <p  align="left">You can add your link absolutely free and with no obligation but there is so much more available that I/we would like to encourage you to keep reading a bit further before you go on to register and add your link information!   
         <p  align="left">First, your web site will be listed in the order that it was received. We don't attempt to "rank" sites, but, instead, we offer you the opportunity to pay for a better position ahead of the earlier links. That payment is then used to compensate the member web site operators for contributing their web traffic to the network. Again, you can add your link for free but we wanted to mention this compensation system because after you add your link you can also add a web directory just like this to your own website for absolutely free too! You too can start to earn something for contributing your own web traffic to our little co-operative as well!
<p  align="left">Second, the network uses a Bitcoin only based payment system and since Bitcoin is such a new Internet payment system we like to take this opportunity to prep you a little bit. Don't let the fact that you never heard of Bitcoin scare you because, remember, you can advertise for free (and just ignore all the Bitcoin related stuff). But we have also gone to great lengths to help educate you about Bitcoin and to provide you with free tools to become experienced with it. In fact, we even built a tool that will let you "pay" with a free test demo version of Bitcoin and move your link ahead of all the previous free links just for trying out and using the demo. Take a peek at the "About Bitcoin" section of the site (located in the web directory's top nav bar). 
<p  align="left">So now that you know that this great web directory is part of a bigger effort than just our own, fill out the form below to register at the co-operative at BungeeBones.com. Then login there,  add your link and, optionally, add a web directory of your own to your website!
</div>     

   <div class="modalFooter">
                     <div class="acc-section">
				<div style="text-align: center;">
				
<iframe src="https://<?php echo $agent_url."/". $agent_folder;?>/members/register.php?referer_lnk_num=<?php echo $_GET['lnk_num'];?>&remote_server=<?php echo $server_url;?>" width="100%" height="750"]
		</iframe>				
</div> 

            <div class="clear"></div>
        </div>
  </div>
