

<div id="openModal" class="modalWindow">
        <div class="modalHeader"><h1 align="center">About Bitcoin</h1></div>
            <p align="left">Bitcoin is a new and revolutionary web technology that can be used for many things. In the case of our blogging club and monetization system we use it as the payment system. Any advertising fees that a web site chooses to incur to move their site into a more prominent position are paid using Bitcoin (unless the buyer has earned advertising credits and is using those instead). Also, all commissions paid to club members for their advertising sales are paid out in Bitcoin.</p>
            <p  align="left">You can find a lot of information about Bitcoin on the web. It has been out now about 5 years and there are many excellent YouTube videos, many excellent web sites, and many excellent news articles.    
         
</div>     
            <div class="clear"></div>
