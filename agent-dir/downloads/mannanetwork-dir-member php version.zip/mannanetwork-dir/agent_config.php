<?php
$agent_url = "agent1.com";
$agent_folder = "manna-network";
?>
