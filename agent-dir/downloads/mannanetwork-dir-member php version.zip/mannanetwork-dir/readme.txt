=== Bungeebones Reciprocal Link Directory & Monetization System PHP Script ===
Contributors: Robert Lefebure

== Description ==
With this script you can make a complete (with categories, links and management) website directory for your own website and, from there, offer your visitors the opportunity to have their website link info displayed across the entire ad network. They will also have access to this same script (or a Wordpress plugin) for their own website. 


 

== Installation ==
1. Download the script and upload it to your website.
2. Unzip the script at whatever level you wish (i.e. you can install it at root level provided there are no file/folder name conflicts with existing files/folders or, alternately you can install it in its own directory named whatever you like). 
3. See the example.php page. Note how the one line of PHP code (<?php include('bungeebones-include.php'); ?>) is placed where the directory appears. Do similiar using a copy of one of your own web pages (i.e. as a template).
4) Create a php page and put the following line of code where you want the web directory to appear on the page <?php include('bungeebones-include.php'); ?>


If you have any questions about installation email me at robert.r.lefebvre@gmail.com and I'll be glad to assist you.




