<script>


const still_more_locs_cont = '<h4 style="font-size:small;">Only listings from that continent will appear.</h4>';
const still_more_locs_coun = '<h4 style="font-size:small;">Only listings from that country will appear.</h4>';
const still_more_locs_stat = '<h4 style="font-size:small;">Only listings from that state  will appear.</h4>';
const still_more_locs_city = '<h4 style="font-size:small;">Only listings from that city  will appear.</h4>';
const still_more_cats = '<h4 style="font-size:small;">Still More Subcategories To Choose From<br>OR Click GO Button.</h4>';

const no_more_subs = '<h4 style="font-size:small;">No More Subs<br>Click Go Or Clear</h4>';
const wording_ajax_free_position = "Free sites are listed and ordered according to their seniority (usually the date/time they registered).<p>\"Demo coins\" are given to each new listing in the ad network (you received 1 demo coin) and can be used to <u>bid for better position</u>. <p>Ads paid with <b>Bitcoin Cash</b> are displayed ahead of both Demo paying ads and free ads. ";
const wording_ajax_free_position1 = "<p>Your free listing will initially be positioned at the ";
const wording_ajax_free_position2 =  ",position which will be on page ";
const wording_ajax_free_position3 =  ",position ";
const wording_ajax_demo_position1 = "If you use the free \"Demo Coin\" (which you will receive immediately after registration) to bid for better position, then the minimum bid (approximately .00019 coin) would move your listing of all free links and up to position ";
const wording_ajax_demo_position2 =  ",which will be on page ";
const wording_ajax_demo_position3 =  ",position ";
const wording_ajax_demo_position4 =  ",<p> There are already ";
const wording_ajax_demo_position5 =  ",advertisers that have bid using their demo coin AND ";
const wording_ajax_demo_position6 =  ",advertisers that have bid using Bitcoin Cash (for a total of ";
const wording_ajax_demo_position7 = " advertisers that would still listed ahead of yours if you bid the <u>minimum</u> with your free demo coin). You can bid more than the minimum with your Demo Coin and achieve higher positions among the Demo Coin group but your allotment won't last as long. To maintain your Demo Coin balance you can install our web directory app on your website and earn them from subscribers that register there (they also receive demo coins). You can also outbid them with even the minimum bid amount of Bitcoin Cash. If you aren't familar with crypto currency, you can take our course at <a target='_blank' href='http://bitcoin101.today'>Bitcoin101.today</a> for just $1.01. ";
const wording_ajax_demo_position8 =  ",<p>The highest \"Demo Coin\" bidder has paid ";
const wording_ajax_demo_position9 =  ",for their top position. ";

const wording_ajax_btc_position1 = "wording_ajax_btc_position1 spaceholder";
const wording_ajax_btc_position2 = "wording_ajax_btc_position2 spaceholder";
const wording_ajax_btc_position3 = "wording_ajax_btc_position3 spaceholder";

const wording_ajax_expanded_header = "<h4>An Expanded View Of The Ad Program ...</h4>";
const wording_ajax_summary_header = "<h4>A Quick Look At Where Your Ad Will Be ...</h4>";
</script>

