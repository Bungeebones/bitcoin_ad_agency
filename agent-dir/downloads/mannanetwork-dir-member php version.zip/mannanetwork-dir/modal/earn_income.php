

<div id="openModal" class="modalWindow">
   <div>
     <div> 
       <div class="modalHeader"><h1 align="center">Earn Income With Our Web Directory!</h1></div> 
            <p align="left">You can earn income (either in the form of Bitcoin or advertising credits) with our web directory. Our sit is one of a network of many on individually owned and operated websites that co-operate together to advertise each other's websites. So when we make this offer available to other webmasters (like yourself) to you add our web directory to your website it means an advertis in it will now be advertised on your website as well as ours. It's a better way for them to advertise their website than what adding it to just your own site could provide by itself.</p>
            <p  align="left">You can choose to display their link absolutely free (and that is our recommendation) but there is so much more available that I would like to encourage you to keep reading a bit further before you go on to register and add your link information!you can also choose to display only paying customers.   
         <p  align="left">First, your web directory will be completely branded to your own website and the page it appears on will look like every one of your other web pages.
<p  align="left">Second, the web directory is totally and completely managed for you so it is absolutely maintenance free. Just install it and collect the commissions! 
<p  align="left">Lastly, it is available for absolutely free! It is available as a simple to install plugin for Wordpress or as a PHP script and can install in minutes.
<p>You need to register and begin advertising your own website as the first step. You too can choose between free advertising or bid for a more prominent position ... it's complely up to you. Then install the web directory using your unique link id and start earning Bitcoin!

</div> 
<? include('footer.php');
?>
            <div class="clear"></div>
        </div>
  </div>
</div>
</div>

